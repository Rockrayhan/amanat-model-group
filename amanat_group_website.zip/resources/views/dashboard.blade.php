@extends('layouts.app')

@section('title', 'GoClova Dashboard')

@section('content')

    <div>


        @if (session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif
    
    @if ($errors->any())
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <ul class="mb-0">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif
    



        <div class="container-fluid pt-4 px-4">
            <div class="row g-4">
                {{-- blogs page --}}
                <div class="col-sm-6 col-xl-3">
                    <a href="{{ route('blogs.index') }}">
                        <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-line fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2"> Blogs </p>
                                <h6 class="mb-0"> {{ $blogs->count() }} </h6>
                            </div>
                        </div>
                    </a>
                </div>

                {{-- Case - Studies Page --}}
                <div class="col-sm-6 col-xl-3">
                    <a href="{{ route('casestudy.index') }}">
                        <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-bar fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2"> Case-Studies </p>
                                <h6 class="mb-0"> {{ $caseStuides->count() }} </h6>
                            </div>
                        </div>
                    </a>
                </div>

                {{-- All API --}}
                <div class="col-sm-6 col-xl-3">
                    <a href="{{ route('api-lists') }}">
                        <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-bar fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2"> All API </p>
                            </div>
                        </div>
                    </a>
                </div>

            </div>
        </div>




    </div>

@endsection
