

<?php $__env->startSection('content'); ?>

<h1>
    Update Case Studies
</h1>
<div class="container mt-4">
    <form action="<?php echo e(route('casestudy.update', $case->id)); ?>" method="POST" enctype="multipart/form-data"onsubmit="syncTinyMCEContent()" novalidate>
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('casestudies.form', ['edit' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <button class="btn btn-success">Update</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp8.2\htdocs\LaraveL\Final Touch Projects\goclova-backend\resources\views/casestudies/edit.blade.php ENDPATH**/ ?>