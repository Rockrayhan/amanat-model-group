

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Available API Endpoints</h2>
    <ul class="list-group">

        <li class="list-group-item">
            <strong>GET /api/blogs</strong>
            <p>Fetch all blog posts.</p>
            <a href="<?php echo e(url('/api/blogs')); ?>" target="_blank">Get Blogs API</a>
        </li>

        <li class="list-group-item">
            <strong>GET /api/case-studies</strong>
            <p>Fetch all case studies.</p>
            <a href="<?php echo e(url('/api/case-studies')); ?>" target="_blank">Get Case-studies API</a>
        </li>

    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp8.2\htdocs\LaraveL\Final Touch Projects\amanat_group_website\resources\views/api-list.blade.php ENDPATH**/ ?>