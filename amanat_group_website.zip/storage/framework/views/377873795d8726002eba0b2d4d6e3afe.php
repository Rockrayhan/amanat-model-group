<?php $__env->startSection('title', 'GoClova Dashboard'); ?>

<?php $__env->startSection('content'); ?>

    <div>


        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    



        <div class="container-fluid pt-4 px-4">
            <div class="row g-4">
                
                <div class="col-sm-6 col-xl-3">
                    <a href="<?php echo e(route('blogs.index')); ?>">
                        <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-line fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2"> Blogs </p>
                                <h6 class="mb-0"> <?php echo e($blogs->count()); ?> </h6>
                            </div>
                        </div>
                    </a>
                </div>

                
                <div class="col-sm-6 col-xl-3">
                    <a href="<?php echo e(route('casestudy.index')); ?>">
                        <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-bar fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2"> Case-Studies </p>
                                <h6 class="mb-0"> <?php echo e($caseStuides->count()); ?> </h6>
                            </div>
                        </div>
                    </a>
                </div>

                
                <div class="col-sm-6 col-xl-3">
                    <a href="<?php echo e(route('api-lists')); ?>">
                        <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-bar fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2"> All API </p>
                            </div>
                        </div>
                    </a>
                </div>

            </div>
        </div>




    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp8.2\htdocs\LaraveL\Final Touch Projects\goclova-backend\resources\views/dashboard.blade.php ENDPATH**/ ?>