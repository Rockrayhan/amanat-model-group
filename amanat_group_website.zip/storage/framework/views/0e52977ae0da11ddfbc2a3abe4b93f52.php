<!DOCTYPE html>
<html>

<head>
    <title><?php echo $__env->yieldContent('title', 'Amanat Group'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/mystyle.css')); ?>">
    
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('/frontend/styles/style.css')); ?>">


    
    
    <link href="https://cdn.jsdelivr.net/npm/daisyui@5" rel="stylesheet" type="text/css" />


    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />

    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />



</head>


<body>
    <header>
        <?php echo $__env->make('frontend.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header>

    <!-- Loader -->
    <div id="pageLoader"
        class="fixed inset-0 bg-white dark:bg-gray-900 z-[9999] flex items-center justify-center opacity-100 transition-opacity duration-500 ease-in-out">

        <div class="flex flex-col items-center space-y-2">
            <!-- Logo -->
            <img src="<?php echo e(asset('/frontend/images/logo.png')); ?>" alt="Loading Logo"
                class="h-52 w-auto animate-pulse rounded-lg shadow" />

            <!-- Spinner -->
            <span class="loading loading-spinner loading-lg text-primary"></span>
        </div>
    </div>


    <div>
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <footer>
        <?php echo $__env->make('frontend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </footer>

    
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>

    
    <script>
        // Fade out loader after page load
        window.addEventListener('load', () => {
            const loader = document.getElementById('pageLoader');
            loader.classList.add('opacity-0');
            setTimeout(() => loader.style.display = 'none', 500);
        });
    </script>


    <?php echo $__env->yieldContent('scripts'); ?>


</body>

</html>
<?php /**PATH H:\xampp8.2\htdocs\LaraveL\Final Touch Projects\amanat_group_website\resources\views/frontend/layouts/app.blade.php ENDPATH**/ ?>