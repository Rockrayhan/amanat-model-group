

<?php $__env->startSection('content'); ?>
<div class="container">

    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <ul class="mb-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

    <h3>Change Password</h3>
    <form method="POST" action="<?php echo e(route('admin.change.password')); ?>">
        <?php echo csrf_field(); ?>
        <input type="password" name="current_password" placeholder="Current Password" class="form-control mb-2" required>
        <input type="password" name="new_password" placeholder="New Password" class="form-control mb-2" required>
        <input type="password" name="new_password_confirmation" placeholder="Confirm New Password" class="form-control mb-2" required>
        <button type="submit" class="btn btn-primary">Change Password</button>
    </form>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp8.2\htdocs\LaraveL\Final Touch Projects\goclova-backend\resources\views/admin/change-password.blade.php ENDPATH**/ ?>