

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <a href="<?php echo e(route('casestudy.create')); ?>" class="btn btn-primary mb-3">Add New</a>
    <?php $__currentLoopData = $cases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $case): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mb-3">
        <div class="card-body">
            <h5><?php echo e($case->title); ?></h5>
    
            <?php if($case->image): ?>
                <img src="<?php echo e(asset($case->image)); ?>" width="150" class="mb-2">
            <?php endif; ?>
    
            <p><?php echo e($case->short_desc); ?></p>
    
            <a href="<?php echo e(route('casestudy.edit', $case->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
            <a href="<?php echo e(route('casestudy.delete', $case->id)); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete?')">Delete</a>
        </div>
    </div>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp8.2\htdocs\LaraveL\Final Touch Projects\goclova-backend\resources\views/casestudies/index.blade.php ENDPATH**/ ?>