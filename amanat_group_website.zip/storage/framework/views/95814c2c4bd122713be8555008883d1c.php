<?php
$edit = $edit ?? false;
?>

<div class="mb-3">
    <label class="form-label">Title</label>
    <input type="text" name="title" value="<?php echo e(old('title', $edit ? $case->title : '')); ?>" class="form-control">
</div>

<div class="mb-3">
    <label class="form-label">Tags (comma-separated)</label>
    <input type="text" name="tags" value="<?php echo e(old('tags', $edit ? implode(',', $case->tags) : '')); ?>" class="form-control">
</div>

<div class="mb-3">
    <label class="form-label">Team Involvement</label>
    <input type="text" name="team_involvement" value="<?php echo e(old('team_involvement', $edit ? $case->team_involvement : '')); ?>" class="form-control">
</div>

<div class="mb-3">
    <label class="form-label">Category</label>
    <input type="text" name="category" value="<?php echo e(old('category', $edit ? $case->category : '')); ?>" class="form-control">
</div>

<div class="mb-3">
    <label class="form-label">Short Description</label>
    <input type="text" name="short_desc" class="form-control" value="<?php echo e(old('short_desc', $edit ? $case->short_desc : '')); ?>"></input>
</div>

<div class="mb-3">
    <label class="form-label">Image</label>
    <input type="file" name="image" class="form-control">
    <?php if($edit && $case->image): ?>
        <img src="<?php echo e($case->image); ?>" width="120" class="mt-2">
    <?php endif; ?>
</div>

<div class="mb-3">
    <label class="form-label">Services We Provided (comma-separated)</label>
    <input type="text" name="services_we_provided" value="<?php echo e(old('services_we_provided', $edit ? implode(',', $case->services_we_provided) : '')); ?>" class="form-control">
</div>

<div class="mb-3">
    <label class="form-label">Industry</label>
    <input type="text" name="industry" value="<?php echo e(old('industry', $edit ? $case->industry : '')); ?>" class="form-control">
</div>

<div class="mb-3">
    <label class="form-label">Year</label>
    <input type="text" name="year" value="<?php echo e(old('year', $edit ? $case->year : '')); ?>" class="form-control">
</div>

<div class="mb-3">
    <label class="form-label">The Problem</label>
    <textarea name="the_problem" class="form-control"><?php echo e(old('the_problem', $edit ? $case->the_problem : '')); ?></textarea>
</div>

<div class="mb-3">
    <label class="form-label">The Solution</label>
    <textarea name="the_solution" class="form-control" rows="4"><?php echo e(old('the_solution', $edit ? $case->the_solution : '')); ?></textarea>
</div>



<div class="mb-3">
    <label class="form-label">The Results</label>
    <textarea name="the_results" class="form-control"><?php echo e(old('the_results', $edit ? $case->the_results : '')); ?></textarea>
</div>
<?php /**PATH H:\xampp8.2\htdocs\LaraveL\Final Touch Projects\goclova-backend\resources\views/casestudies/form.blade.php ENDPATH**/ ?>