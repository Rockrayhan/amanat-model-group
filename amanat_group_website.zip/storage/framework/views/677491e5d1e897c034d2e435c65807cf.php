

<?php $__env->startSection('content'); ?>
<div class="container pb-5 mb-5">
    <h2>All Blogs</h2>
    <a href="<?php echo e(route('blogs.create')); ?>" class="btn btn-primary mb-3">+ Add New Blog</a>

    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mb-2">
        <div class="card-body">
            <h4><?php echo e($blog->title); ?></h4>
            <p>Author: <?php echo e($blog->author); ?> | Category: <?php echo e($blog->category); ?></p>
            <?php if($blog->image): ?>
                <img src="<?php echo e(asset($blog->image)); ?>" width="150">
            <?php endif; ?>
            <p><?php echo Str::limit(strip_tags($blog->description), 100); ?></p>
            <small>Featured: <?php echo e($blog->featured_in_home ? 'Yes' : 'No'); ?></small>
            <br>
    
            <!-- Action buttons -->
            <a href="<?php echo e(route('blogs.edit', $blog->id)); ?>" class="btn btn-warning btn-sm mt-2">Edit</a>
            <a href="<?php echo e(route('blogs.delete', $blog->id)); ?>" class="btn btn-danger btn-sm mt-2" onclick="return confirm('Are you sure to delete?')">Delete</a>
        </div>
    </div>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php echo e($blogs->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp8.2\htdocs\LaraveL\Final Touch Projects\goclova-backend\resources\views/blogs/index.blade.php ENDPATH**/ ?>