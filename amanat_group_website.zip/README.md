https://www.transcombd.com/     ==> 	1. banner ( arrow / bellow dot / bellow mark, background image - front text )
										8. our clients //
										* buttons

https://www.akij.net/ 		    ==> 	2. about 1st //
					                    3. about 2nd //
					                    4. vision //
					                    5. our brands / companies pofile ( animation like asg ) //


https://asg-bd.com/		        ==>     6.our services //
										* short about
										9. our location
										10. Contact us with Our offices 



https://www.citygroup.com.bd/	==> 	7. News and Events ( arrow button ) // ( make dynamic )
					                    10. management
					


requiremnts: smooth scroll, aos animation, animate.css

Company list:
1. AMANAT MODEL FOUNDATION 
2. AMANAT TRADING COOPERATIVE BANK 
3. AMANAT MODEL AGRO LIMITED 
4. AMANAT MODEL FOOD AND BEVERAGE LIMITED 










1. managemnet page //
2. contact page //
3. navbar -> (active link, hover animation, sticky, bg blur, mega menu)
5. globe
6. loader with logo
7. back to top
8. aos animation

<!-- <x-frontend.show-more-button /> -->